package org.darkfireworld.post;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

/**
 * Created by Administrator on 2016/8/10.
 */
@Component
public class MyBeanPostProcessor implements BeanPostProcessor, DisposableBean {
    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public MyBeanPostProcessor() {
        logger.error("MyBeanPostProcessor");
    }

    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        logger.error("postProcessBeforeInitialization  " + beanName);
        return bean;
    }

    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        logger.error("postProcessAfterInitialization  " + beanName);
        return bean;
    }

    public void destroy() throws Exception {
        logger.error("destroy MyBeanPostProcessor");
    }
}
