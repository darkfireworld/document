package org.darkfireworld.post;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Created by Administrator on 2016/8/11.
 */
@Component
@Aspect
public class MyAop {
    Logger logger = LoggerFactory.getLogger(this.getClass());

    @Pointcut("execution(* org.darkfireworld.bean.impl.ManImpl.*(..))")
    private void pointCutMethod() {
    }

    //声明环绕通知
    @Around("pointCutMethod()")
    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {
        logger.error("invoke " + pjp.getSignature().toString() + " before");
        Object o = pjp.proceed();
        logger.error("invoke " + pjp.getSignature().toString() + " after");
        return o;
    }
}