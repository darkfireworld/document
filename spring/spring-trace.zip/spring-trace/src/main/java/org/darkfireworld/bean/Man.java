package org.darkfireworld.bean;

/**
 * Created by Administrator on 2016/8/10.
 */
public interface Man {
    void say();
}
