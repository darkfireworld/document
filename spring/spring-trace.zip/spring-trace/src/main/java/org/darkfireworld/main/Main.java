package org.darkfireworld.main;

import org.darkfireworld.bean.Man;
import org.darkfireworld.conf.SpringConf;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Created by Administrator on 2016/8/10.
 */
public class Main {
    static public void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConf.class);
        Man man = context.getBean(Man.class);
        man.say();
    }
}
