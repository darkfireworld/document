package org.darkfireworld.main;

import org.darkfireworld.bean.Man;
import org.darkfireworld.conf.SpringConf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Created by Administrator on 2016/8/10.
 */
public class Main {
    static Logger logger = LoggerFactory.getLogger(Main.class);

    static public void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConf.class);
        Man man = context.getBean(Man.class);
        man.say();
        logger.error("Close Context");
        context.close();
    }
}
