package org.darkfireworld.bean;

import org.springframework.stereotype.Component;

@Component
public class Test {
}
