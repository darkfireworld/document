package org.darkfireworld.bean.impl;

import org.darkfireworld.bean.Man;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.MessageSourceAware;
import org.springframework.stereotype.Component;

@Component
public class ManImpl implements Man {
    public ManImpl() {
        System.out.print("INIT MAN");
    }

    public void say() {
        System.out.println("I am Man");
    }
}
