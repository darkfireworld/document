package org.darkfireworld.bean.impl;

import org.darkfireworld.bean.Man;
import org.darkfireworld.bean.Test;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ManImpl implements InitializingBean,Man {
    public ManImpl() {
        System.out.println("A");
    }

    @Autowired
    Test test;

    public void say() {
        System.out.println("Crazy");
        tet();
    }
    public void tet(){
        System.out.println("testC");
    }
    public void afterPropertiesSet() throws Exception {
        System.out.println("HAHHA");
    }
}
