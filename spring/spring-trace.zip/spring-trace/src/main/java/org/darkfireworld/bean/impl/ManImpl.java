package org.darkfireworld.bean.impl;


import org.darkfireworld.bean.Man;
import org.darkfireworld.bean.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ManImpl implements InitializingBean, Man, DisposableBean {
    Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    Test test;

    public ManImpl() {
        logger.error("INIT MAN IMPL");
    }

    public void say() {
        logger.error("Say Crazy");
        test();
    }

    public void test() {
        logger.error("test Aop");
    }

    public void afterPropertiesSet() throws Exception {
        logger.error("afterPropertiesSet");
    }

    public void destroy() throws Exception {
        logger.error("destroy ManImpl");
    }
}
